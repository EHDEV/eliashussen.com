Contributors
============
hugo-vitae is an open source project in development and lives from the
collaboration of others.

*Please edit this list to include new contributors.*

* [Benedikt Tuchen](https://github.com/dataCobra)
* [Mark Petherbridge](https://github.com/markdevjapan)
* [Christoph Petrausch](https://github.com/hikhvar)
* [Mohamed Muhannad](https://github.com/muhannad0)